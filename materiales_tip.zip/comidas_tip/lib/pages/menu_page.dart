import 'package:flutter/material.dart';
import 'package:comidas_tip/model/comida.dart';
import 'package:flutter/cupertino.dart';

void main() {
  runApp(MaterialApp(home: MenuPage()));
}

class MenuPage extends StatefulWidget {
  @override
  _MenuPageState createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  final items = <comida>[
    comida('descriptioncomida', 'Pan de muerto', 10.00),
    comida('descriptioncomida', 'Chile en Nogada', 50.00),
    comida('descriptioncomida', 'Taco de pastor', 10.00),
    comida('descriptioncomida', 'Pizza', 120.00),
    comida('descriptioncomida', 'Churros', 13.00),
    comida('descriptioncomida', 'Gorditas', 13.00),
    comida('descriptioncomida', 'Enchiladas', 25.00),
    comida('descriptioncomida', 'Rajas de chile', 20.00),
    comida('descriptioncomida', 'Huaraches', 50.00),
    comida('descriptioncomida', 'Chiles jalapeños rellenos', 40.00),
    comida('descriptioncomida', 'Chocolate caliente', 12.00),
    comida('descriptioncomida', 'Pan dulce', 10.00),
    comida('descriptioncomida', 'Tacos de carnitas', 17.00),
    comida('descriptioncomida', 'Refrescos', 15.00),
    comida('descriptioncomida', 'Café', 14.00),
  ];

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(
                top: size.height * 0.18,
              ),
              child: SafeArea(
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 1),
                  itemCount: 15,
                  itemBuilder: (BuildContext context, int i) {
                    return Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Image.asset(
                              'assets/img/pan.jpg',
                              height: size.height * .13,
                            ),
                          ),
                          Text(
                            '${items[i].namecomida}'.toUpperCase(),
                            style: TextStyle(
                              fontSize: 23.0,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text('${items[i].descriptioncomida}'),
                          Text(
                            '\$${items[i].pricecomida}',
                            style: TextStyle(
                              fontSize: 20.0,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                      color: Colors.blue[80],
                      elevation: 10.0,
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
