class comida {
  final String namecomida;
  final String descriptioncomida;
  final double pricecomida;
  comida(this.descriptioncomida, this.namecomida, this.pricecomida);
}
